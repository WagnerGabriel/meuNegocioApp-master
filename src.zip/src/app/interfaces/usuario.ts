export interface Usuario {
    nome?: string;
    email?: string;
    senha?: string;
}
