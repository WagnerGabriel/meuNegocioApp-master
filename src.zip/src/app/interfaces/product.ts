export interface product {
    id?:string;
    name?:string;
    description?:string;
    price?:string;
    createdAt?:number;
    userId?:string;
}